#!/bin/bash

echo ">>> 开始部署 robot_reporter 服务..."

SERVICE_FILE="/home/master/mqtt_py_reporter/robot_reporter.service"

cp "${SERVICE_FILE}" /etc/systemd/system/

# 重新加载 systemd 配置，启用并启动服务
systemctl daemon-reload
systemctl enable robot_reporter.service
systemctl restart robot_reporter.service

echo ">>> 部署完成！"
systemctl status robot_reporter.service --no-pager