# 后续工程化考虑添加虚拟环境和依赖安装，如果离线环境添加离线安装包
```shell
# 使用虚拟环境
python -m venv reporter_env
source reporter_env/bin/activate

# 在线安装 添加 requirements.txt
pip install -r requirements.txt

# 离线安装 下载所有依赖到本地目录（不安装）
pip download -r requirements.txt -d ./offline_packages/
# 从本地目录离线安装（--no-index 禁止联网，-f 指定本地包目录）
pip install --no-index --find-links=./offline_packages/ -r requirements.txt
```

# 第一步，在机器人中解压安装包
进入用户目录`cd ~`，创建目录并解压安装包：

```shell
mkdir -p mqtt_py_reporter && tar -xzvf mqtt_py_reporter.tar.gz -C mqtt_py_reporter
```

# 第二步，部署配置服务自启动
进入解压后的目录 `cd mqtt_py_reporter`，为部署脚本添加执行权限并运行：

```shell
sudo chmod +x ./deploy.sh
sudo ./deploy.sh
```

服务正常启动后，可通过以下命令查看日志：

```shell
tail -f ./log/reporter.log
```
