#!/usr/bin/env python3
"""
MQTT 属性上报示例脚本

周期性上报模拟的属性数据到 IoT 平台。
仅演示属性上报功能，不包含事件和服务。

用法:
    python reporter.py
    python reporter.py --dev-info /path/to/dev_info.txt
"""

from __future__ import annotations

import argparse
import glob
import json
import logging
import os
import random
import subprocess
import sys
import threading
import time
from dataclasses import dataclass, field
from typing import Optional

from iot_mqtt_sdk import IoTMTTTSDK


@dataclass
class BatteryInfoStruct:
    voltage: int = 0
    current: int = 0
    soc: int = 0
    temperature: int = 0
    status: int = 2


@dataclass
class OdomStruct:
    x: float = 0.0
    y: float = 0.0
    theta: float = 0.0


@dataclass
class PropertyStruct:
    battery_info: Optional[BatteryInfoStruct] = field(default=None)
    ap_info: Optional[str] = field(default=None)
    head_pos: Optional[object] = field(default=None)
    net_info: Optional[str] = field(default=None)
    odom: Optional[OdomStruct] = field(default=None)
    version: Optional[str] = field(default=None)
    imu_state: Optional[object] = field(default=None)
    robot_status: Optional[int] = field(default=None)
    motor_1: Optional[object] = field(default=None)
    motor_2: Optional[object] = field(default=None)
    motor_3: Optional[object] = field(default=None)
    motor_4: Optional[object] = field(default=None)

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s.%(msecs)03d  [%(levelname)s] %(name)s:%(lineno)d: %(message)s",
    datefmt="%H:%M:%S",
)
logger = logging.getLogger("reporter")

# ============================================================
# 全局配置
# ============================================================
VERSION="1.0.0"
REPORT_INTERVAL_SECONDS = 5

_SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
_DEV_INFO_DIR = os.path.abspath(os.path.join(_SCRIPT_DIR, ".."))

# 网络/WiFi 信息缓存（每60秒更新一次）
_net_info = ""
_ap_info = ""


def update_net_info():
    global _net_info
    try:
        result = subprocess.run(
            ["ip", "addr"], capture_output=True, text=True, timeout=5
        )
        net_entries = []
        current_iface = None
        mac_addr = None
        ip_addr = None

        for line in result.stdout.splitlines():
            line_stripped = line.strip()
            if not line_stripped:
                continue
            if line_stripped.startswith("inet ") and current_iface:
                ip_addr = line_stripped.split()[1].split("/")[0]
                continue
            parts = line_stripped.split()
            if len(parts) >= 1:
                token = parts[0]
                if token.endswith(":") and len(token) > 1:
                    iface_name = token[:-1]
                    try:
                        int(iface_name)
                        if len(parts) >= 2 and parts[1].endswith(":"):
                            iface_name = parts[1][:-1]
                    except ValueError:
                        pass
                    if current_iface and ip_addr and mac_addr and current_iface != "lo":
                        net_entries.append(f"{current_iface}:{ip_addr}:{mac_addr}")
                    current_iface = iface_name
                    ip_addr = None
                    mac_addr = None
                elif token == "link/ether" and len(parts) >= 2:
                    mac_addr = parts[1].upper().replace(":", "")

        if current_iface and ip_addr and mac_addr and current_iface != "lo":
            net_entries.append(f"{current_iface}:{ip_addr}:{mac_addr}")

        _net_info = ",".join(net_entries)
        logger.info(f"[NET] Updated net_info: {_net_info[:200]}")
    except Exception as e:
        logger.error(f"[NET] Failed to get network info: {e}")
        _net_info = ""


def update_ap_info():
    threading.Thread(target=_update_ap_info_async, daemon=True).start()


def _update_ap_info_async():
    global _ap_info
    try:
        result = subprocess.run(
            ["nmcli", "-t", "-f", "active,ssid,signal,bssid", "dev", "wifi"],
            capture_output=True,
            text=True,
            timeout=5,
        )
        for line in result.stdout.splitlines():
            if line.startswith("是:") or line.startswith("yes:"):
                parts = line.split(":")
                if len(parts) >= 4:
                    ssid = parts[1].replace("\\:", ":")
                    rssi = parts[2]
                    bssid = "".join(parts[3:]).replace("\\", "").upper()
                    _ap_info = f"{ssid}:{rssi}:{bssid}"
                    logger.info(f"[AP] Updated ap_info: {_ap_info}")
                    return
        _ap_info = ""
        logger.warning("[AP] No connected WiFi AP found")
    except Exception as e:
        logger.error(f"[AP] Failed to get AP info: {e}")
        _ap_info = ""


def _start_net_ap_timers():
    update_net_info()
    update_ap_info()

    def _net_loop():
        while True:
            time.sleep(60)
            update_net_info()

    def _ap_loop():
        while True:
            time.sleep(60)
            update_ap_info()

    threading.Thread(target=_net_loop, daemon=True).start()
    threading.Thread(target=_ap_loop, daemon=True).start()


def _parse_dev_info(path: str) -> dict:
    info = {}
    with open(path) as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            parts = line.split(",", 1)
            if len(parts) == 2:
                key = parts[0].strip()
                value = parts[1].strip()
                info[key] = value
    return info


def find_dev_info(path=None):
    if path:
        if os.path.isfile(path):
            return _parse_dev_info(path)
        raise FileNotFoundError(f"指定的 dev_info 文件不存在: {path}")
    # 按 dev_info_ 前缀查找目录下第一个 .txt 文件
    matches = sorted(glob.glob(os.path.join(_DEV_INFO_DIR, "dev_info_*.txt")))
    if matches:
        found = matches[0]
        logger.info(f"使用设备信息文件: {found}")
        return _parse_dev_info(found)
    raise FileNotFoundError(
        f"未找到 dev_info_*.txt，请通过 --dev-info 参数指定路径"
    )

def generate_simulated_property() -> PropertyStruct:
    prop = PropertyStruct()
    prop.battery_info = BatteryInfoStruct(
        voltage=random.randint(460, 500),
        current=random.randint(-50, 50),
        soc=random.randint(75, 95),
        temperature=random.randint(30, 40),
        status=1,
    )

    prop.odom = OdomStruct(
        x=round(random.uniform(0.0, 10.0), 2),
        y=round(random.uniform(0.0, 10.0), 2),
        theta=round(random.uniform(-3.14, 3.14), 2),
    )
    
    prop.net_info = _net_info
    prop.ap_info = _ap_info
    prop.version = VERSION
    prop.robot_status = 1

    return prop


def build_property_payload(property_data: PropertyStruct) -> dict:
    data_list = []
    data = property_data

    if data.battery_info is not None:
        data_list.append({
            "key": "battery_info",
            "value": {
                "soc": data.battery_info.soc,
                "voltage": data.battery_info.voltage,
                "current": data.battery_info.current,
                "temperature": data.battery_info.temperature,
                "status": data.battery_info.status,
            }
        })
    
    if data.odom is not None:
        data_list.append({
            "key": "odom",
            "value": {
                "x": data.odom.x,
                "y": data.odom.y,
                "theta": data.odom.theta,
            }
        })
        
    if data.net_info is not None and data.net_info != "":
        data_list.append({"key": "net_info", "value": data.net_info})
        
    if data.ap_info is not None and data.ap_info != "":
        data_list.append({"key": "ap_info", "value": data.ap_info})
        
    if data.version is not None and data.version != "":
        data_list.append({"key": "version", "value": data.version})
  
    if data.robot_status is not None:
        data_list.append({"key": "robot_status", "value": data.robot_status})
        
    return {
        "messageId": str(int(time.time() * 1000)),
        "params": {"data": data_list},
    }

def main():
    parser = argparse.ArgumentParser(description="MQTT 属性上报示例")
    parser.add_argument("--dev-info", default=None, help="指定 dev_info.txt 路径")
    args = parser.parse_args()

    try:
        dev_info = find_dev_info(args.dev_info)
    except FileNotFoundError as e:
        logger.error(e)
        sys.exit(1)

    product_key = dev_info["product_key"]
    device_key = dev_info["device_key"]
    device_secret = dev_info["device_secret"]

    url = dev_info.get("url", "dmp-mqtt.cuiot.cn:1883")
    mqtt_ip, mqtt_port_str = url.rsplit(":", 1)
    mqtt_port = int(mqtt_port_str)

    logger.info(f"product_key={product_key}, device_key={device_key}")
    logger.info(f"MQTT {mqtt_ip}:{mqtt_port}, 上报间隔 {REPORT_INTERVAL_SECONDS}s")

    sdk = IoTMTTTSDK(
        product_key=product_key,
        device_key=device_key,
        device_secret=device_secret,
        mqtt_ip=mqtt_ip,
        mqtt_port=mqtt_port,
    )
    if not sdk.connect():
        logger.error("MQTT 连接失败")
        sys.exit(1)

    logger.info("连接成功，开始周期上报属性 (Ctrl+C 停止)")

    # 启动 net_info / ap_info 后台定时更新（每60秒）
    _start_net_ap_timers()

    try:
        while True:
            prop = generate_simulated_property()
            payload = build_property_payload(prop)
            ok = sdk.report_property_batch(payload)
            item_count = len(payload["params"]["data"])
            if ok:
                logger.info(f"上报成功 | messageId={payload['messageId']} | 属性数={item_count}")
            else:
                logger.warning(f"上报失败 | messageId={payload['messageId']}")
            time.sleep(REPORT_INTERVAL_SECONDS)
    except KeyboardInterrupt:
        logger.info("收到停止信号")
    finally:
        sdk.disconnect()
        logger.info("程序退出")


if __name__ == "__main__":
    main()
