import paho.mqtt.client as mqtt
import json
import time
import threading
import hmac
import hashlib
from typing import Dict, Optional, Union, Tuple

import logging
logger = logging.getLogger(__name__)


class IoTMTTTSDK:
    KEEP_ALIVE = 60
    RECONNECT_INTERVAL = 5

    _TOPIC_PROPERTY_SINGLE = "$sys/{product_key}/{device_key}/property/pub"
    _TOPIC_PROPERTY_BATCH = "$sys/{product_key}/{device_key}/property/batch"
    _TOPIC_EVENT_SINGLE = "$sys/{product_key}/{device_key}/event/pub"
    _TOPIC_EVENT_BATCH = "$sys/{product_key}/{device_key}/event/batch"
    _TOPIC_SERVICE_REPLY = "$sys/{product_key}/{device_key}/service/pub_reply"
    _TOPIC_SERVICE_PUB = "$sys/{product_key}/{device_key}/service/pub"

    def __init__(
        self,
        product_key: str,
        device_key: str,
        device_secret: str,
        mqtt_ip: str = "dmp-mqtt.cuiot.cn",
        mqtt_port: int = 1883,
        service_command_callback: Optional[callable] = None,
    ):
        self.product_key = product_key
        self.device_key = device_key
        self.device_secret = device_secret
        self.mqtt_ip = mqtt_ip
        self.mqtt_port = mqtt_port
        self._handle_service_command = service_command_callback

        # MQTT客户端对象
        self._mqtt_client: Optional[mqtt.Client] = None
        # 存储接收的下行消息
        self.received_messages = {}
        self._reconnect_timer: Optional[threading.Timer] = None
        self._should_reconnect = True

    def _generate_mqtt_auth_info(self) -> Tuple[str, str, str]:
        """生成MQTT连接所需的clientId、username、password"""
        device_id = self.device_key
        # 构建消息内容
        message = device_id + self.device_key + self.product_key
        # 构建用户名
        username = f"{self.device_key}|{self.product_key}"
        # 构建客户端ID
        client_id = f"{device_id}|{self.product_key}|0|0|0"
        # 生成HMAC-SHA256密码
        sha256_hmac = hmac.new(
            self.device_secret.encode("utf-8"), message.encode("utf-8"), hashlib.sha256
        )
        password = sha256_hmac.digest().hex()
        return client_id, username, password

    def connect(self, max_retry: int = 10) -> bool:
        """
        连接MQTT服务器
        :param max_retry: 最大重试次数
        :return: 连接成功返回True，失败返回False
        """
        if self._mqtt_client and self._mqtt_client.is_connected():
            logger.info("MQTT客户端已连接，无需重复连接")
            return True

        try:
            # 生成认证信息
            client_id, username, password = self._generate_mqtt_auth_info()
            logger.info(f"生成MQTT认证信息 - ClientID: {client_id}, Username: {username}, Password (HMAC): {password} (32 bytes)")
            
            # 创建MQTT客户端
            self._mqtt_client = mqtt.Client(
                callback_api_version=mqtt.CallbackAPIVersion.VERSION2,
                client_id=client_id,
                protocol=mqtt.MQTTv31,
            )
            self._mqtt_client.username_pw_set(username=username, password=password)
            # 注册消息回调
            self._mqtt_client.on_message = self._on_message_callback
            self._mqtt_client.on_disconnect = self._on_disconnect_callback

            # 连接服务器
            logger.info(f"正在连接MQTT服务器 {self.mqtt_ip}:{self.mqtt_port}...")
            self._mqtt_client.connect(
                host=self.mqtt_ip, port=self.mqtt_port, keepalive=self.KEEP_ALIVE
            )
            # 启动网络循环
            self._mqtt_client.loop_start()

            # 等待连接成功
            retry_count = 0
            while not self._mqtt_client.is_connected():
                if retry_count >= max_retry:
                    logger.error(f"MQTT连接重试{max_retry}次后失败")
                    return False
                logger.info(f"等待MQTT连接...（{retry_count+1}/{max_retry}）")
                time.sleep(1)
                retry_count += 1

            # 订阅下行消息Topic
            self._subscribe_downstream_topics()
            logger.info("MQTT连接成功，已订阅所有下行Topic")
            return True

        except Exception as e:
            logger.error(f"MQTT连接失败：{str(e)}")
            return False

    def _subscribe_downstream_topics(self) -> None:
        """订阅下行消息Topic（平台下发的回复/指令）"""
        if not self._mqtt_client:
            raise RuntimeError("MQTT客户端未初始化")

        # 下行Topic列表
        downstream_topics = [
            f"$sys/{self.product_key}/{self.device_key}/property/pub_reply",
            f"$sys/{self.product_key}/{self.device_key}/property/batch_reply",
            f"$sys/{self.product_key}/{self.device_key}/event/pub_reply",
            f"$sys/{self.product_key}/{self.device_key}/event/batch_reply",
            f"$sys/{self.product_key}/{self.device_key}/service/pub",
        ]

        for topic in downstream_topics:
            self._mqtt_client.subscribe(topic, qos=0)
            logger.info(f"已订阅下行Topic：{topic}")

    def _on_disconnect_callback(self, client, userdata, disconnect_flags, reasonCode, properties):
        if reasonCode != 0:
            logger.warning(f"[MQTT] 连接断开，reasonCode={reasonCode}，准备重连...")
            self._schedule_reconnect()
        else:
            logger.info("[MQTT] 正常断开连接")

    def _schedule_reconnect(self):
        """调度重连"""
        if self._reconnect_timer:
            self._reconnect_timer.cancel()
        if self._should_reconnect:
            logger.info(f"[MQTT] {self.RECONNECT_INTERVAL}秒后尝试重连...")
            self._reconnect_timer = threading.Timer(self.RECONNECT_INTERVAL, self._do_reconnect)
            self._reconnect_timer.start()

    def _do_reconnect(self):
        """执行重连"""
        if not self._should_reconnect:
            return
        try:
            if self._mqtt_client:
                logger.info("[MQTT] 尝试重连...")
                self._mqtt_client.reconnect()
                retry_count = 0
                while not self._mqtt_client.is_connected():
                    if retry_count >= 10:
                        logger.error("[MQTT] 重连失败")
                        self._schedule_reconnect()
                        return
                    time.sleep(1)
                    retry_count += 1
                self._subscribe_downstream_topics()
                logger.info("[MQTT] 重连成功")
        except Exception as e:
            logger.error(f"[MQTT] 重连异常：{str(e)}")
            self._schedule_reconnect()

    def _on_message_callback(self, client, userdata, msg):
        """处理接收的MQTT消息"""
        try:
            payload = json.loads(msg.payload.decode("utf-8"))
            self.received_messages[msg.topic] = payload
            logger.info(f"收到下行消息 [Topic: {msg.topic}]：{payload}")

            if msg.topic.endswith("/service/pub"):
                # 处理平台下发的服务调用指令
                self._handle_service_command(payload)

        except Exception as e:
            logger.error(f"解析下行消息失败：{str(e)}，原始消息：{msg.payload}")

    def _publish_message(
        self, topic: str, payload: Dict, qos: int = 1, max_retry: int = 5
    ) -> bool:
        """
        通用消息发布方法
        :param topic: 发布的Topic
        :param payload: 消息体（字典）
        :param qos: QoS等级
        :param max_retry: 最大重试次数
        :return: 发布成功返回True，失败返回False
        """
        if not self._mqtt_client or not self._mqtt_client.is_connected():
            logger.warning("MQTT未连接，请先调用connect()方法")
            return False

        try:
            payload_str = json.dumps(payload)
            result = self._mqtt_client.publish(topic, payload_str, qos=qos)

            # 等待发布成功
            retry_count = 0
            while not result.is_published():
                if retry_count >= max_retry:
                    logger.error(f"消息发布重试{max_retry}次后失败")
                    return False
                time.sleep(1)
                retry_count += 1

            logger.info(f"消息发布成功 [Topic: {topic}]")
            return True

        except Exception as e:
            logger.error(f"消息发布失败：{str(e)}")
            return False

    def report_property_single(self, payload: Dict) -> bool:
        topic = self._TOPIC_PROPERTY_SINGLE.format(
            product_key=self.product_key, device_key=self.device_key
        )
        return self._publish_message(topic, payload)

    def report_property_batch(self, payload: Dict) -> bool:
        topic = self._TOPIC_PROPERTY_BATCH.format(
            product_key=self.product_key, device_key=self.device_key
        )
        return self._publish_message(topic, payload)

    def report_event_single(self, payload: Dict) -> bool:
        topic = self._TOPIC_EVENT_SINGLE.format(
            product_key=self.product_key, device_key=self.device_key
        )
        return self._publish_message(topic, payload)

    def report_event_batch(self, payload: Dict) -> bool:
        topic = self._TOPIC_EVENT_BATCH.format(
            product_key=self.product_key, device_key=self.device_key
        )
        return self._publish_message(topic, payload)

    def send_service_reply(self, payload: Dict) -> bool:
        reply_topic = self._TOPIC_SERVICE_REPLY.format(
            product_key=self.product_key, device_key=self.device_key
        )
        return self._publish_message(reply_topic, payload)

    def disconnect(self) -> None:
        self._should_reconnect = False
        if self._reconnect_timer:
            self._reconnect_timer.cancel()
            self._reconnect_timer = None
        if self._mqtt_client:
            self._mqtt_client.loop_stop()
            self._mqtt_client.disconnect()
            logger.info("MQTT连接已断开")
            self._mqtt_client = None

    def __del__(self):
        self.disconnect()
